#include "hardwareinterface.h"

HardwareInterfaceConfigWindow::HardwareInterfaceConfigWindow()
{
}
