#include "mainsimulator.h"
#include "measuresetup.h"
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QFileDialog>
MainSimulator::MainSimulator(QWidget *parent) :
    QMainWindow(parent)
//    ui(new Ui::MainSimulator)
{
    setupUi(this);
    m_MeasureWindow = NULL;
    m_MeasureModel = NULL;
//    QMdiSubWindow * subWin;
//    MeasureSetupWindow* measureWindow = new MeasureSetupWindow(this);
//    measureWindow->setWindowTitle("Measurement Setup");
//    measureWindow->showMaximized();
//    QMdiArea * mdiArea = new QMdiArea(this);
//    setCentralWidget(mdiArea);
//    subWin =  mdiArea->addSubWindow(measureWindow,0);
//    subWin->showMaximized();
    connect(actionOpenConfig,SIGNAL(triggered()),this, SLOT(slotOpenConfig()));

}

MainSimulator::~MainSimulator()
{
//    delete ui;
}

void MainSimulator::showMeasureSetup()
{
    if(m_MeasureWindow){
        m_MeasureWindow->showMaximized();
    }else{
        if(!m_MeasureModel){
            m_MeasureModel = new MeasureSetupModel(m_ConfigPath);
        }
        QMdiSubWindow * subWin;
        m_MeasureWindow = new MeasureSetupWindow(this,m_MeasureModel);
        m_MeasureWindow->setWindowTitle("Measurement Setup");
        QMdiArea * mdiArea = new QMdiArea(this);
        setCentralWidget(mdiArea);
        subWin =  mdiArea->addSubWindow(m_MeasureWindow,0);
        connect(m_MeasureWindow,SIGNAL(destroyed()),this, SLOT(slotCloseMeasureSetup()));
//        subWin->showMaximized();
    }
}

void MainSimulator::slotOpenConfig()
{
    QFileDialog * fileDialog=new QFileDialog();
//    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Create new database file"), QDir::currentPath(), ("Database files (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    QString fileName = QFileDialog::getOpenFileName( fileDialog, ("Open configuration"), QDir::currentPath(), ("Configuration file (*.json);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );
    if(!fileName.isEmpty()){
        if(m_MeasureWindow){
            delete m_MeasureWindow;
            m_MeasureWindow = NULL;
        }
        m_ConfigPath = fileName;
        showMeasureSetup();
    }
}

void MainSimulator::slotCloseMeasureSetup(){
    qDebug()<<__FUNCTION__<<__LINE__;
    m_MeasureWindow = NULL;
}

