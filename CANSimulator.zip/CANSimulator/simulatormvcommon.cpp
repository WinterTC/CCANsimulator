#include "simulatormvcommon.h"
#include <QDebug>
MeasureSetupCommonModel::MeasureSetupCommonModel(QObject *parent)
    : QAbstractItemModel(parent),
   rootItem(NULL)
{
}

MeasureSetupCommonModel::~MeasureSetupCommonModel()
{
    delete rootItem;
}

int MeasureSetupCommonModel::columnCount(const QModelIndex & /* parent */) const
{
   return rootItem->columnCount();
}

QModelIndex MeasureSetupCommonModel::index(int row, int column, const QModelIndex &parent) const
{
    if (parent.isValid() && parent.column() != 0)
        return QModelIndex();
    MeasureSetupCommonItemModel *parentItem = getItem(parent);

    MeasureSetupCommonItemModel *childItem = parentItem->child(row);
    if (childItem)
        return createIndex(row, column, childItem);
    else
        return QModelIndex();
}

bool MeasureSetupCommonModel::insertColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginInsertColumns(parent, position, position + columns - 1);
    success = rootItem->insertColumns(position, columns);
    endInsertColumns();
    return success;
}

bool MeasureSetupCommonModel::insertRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MeasureSetupCommonItemModel *parentItem = getItem(parent);
    beginInsertRows(parent, position, position + rows - 1);
    success = parentItem->insertChildren(position, rows, rootItem->columnCount(),E_ModelItemType_None);
    endInsertRows();
    return success;
}

QModelIndex MeasureSetupCommonModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();
    MeasureSetupCommonItemModel *childItem = getItem(index);
    MeasureSetupCommonItemModel *parentItem = childItem->parent();

    if (parentItem == rootItem)
        return QModelIndex();
    return createIndex(parentItem->childNumber(), 0, parentItem);
}

bool MeasureSetupCommonModel::removeColumns(int position, int columns, const QModelIndex &parent)
{
    bool success = true;
    beginRemoveColumns(parent, position, position + columns - 1);
    success = rootItem->removeColumns(position, columns);
    endRemoveColumns();

    if (rootItem->columnCount() == 0)
        removeRows(0, rowCount());
    return success;
}

bool MeasureSetupCommonModel::removeRows(int position, int rows, const QModelIndex &parent)
{
    bool success = true;
    MeasureSetupCommonItemModel *parentItem = getItem(parent);
    beginRemoveRows(parent, position, position + rows - 1);
    success = parentItem->removeChildren(position, rows);
    endRemoveRows();
    return success;
}

int MeasureSetupCommonModel::rowCount(const QModelIndex &parent) const
{
    MeasureSetupCommonItemModel *parentItem = getItem(parent);
    return parentItem->childCount();
}

MeasureSetupCommonItemModel *MeasureSetupCommonModel::getItem(const QModelIndex &index) const
{
    if (index.isValid()) {
        MeasureSetupCommonItemModel *item = static_cast<MeasureSetupCommonItemModel*>(index.internalPointer());
        if (item)
            return item;
    }
    return rootItem;
}

MeasureSetupCommonItemModel::MeasureSetupCommonItemModel(QVector<QVariant> &data,E_ModelItemType itemType, MeasureSetupCommonItemModel *parent)
{
    parentItem = parent;
    itemData = data;
    m_itemType = itemType;
}

MeasureSetupCommonItemModel::~MeasureSetupCommonItemModel()
{
    qDeleteAll(childItems);
}

MeasureSetupCommonItemModel *MeasureSetupCommonItemModel::child(int number)
{
    return childItems.value(number);
}

int MeasureSetupCommonItemModel::childCount() const
{
    return childItems.count();
}

int MeasureSetupCommonItemModel::childNumber() const
{
    if (parentItem)
        return parentItem->childItems.indexOf(const_cast<MeasureSetupCommonItemModel*>(this));
    return 0;
}

int MeasureSetupCommonItemModel::columnCount() const
{
    return itemData.size();
}

QVariant  MeasureSetupCommonItemModel::data(int column) const
{
    return itemData.value(column);
}
bool MeasureSetupCommonItemModel::insertChildren(int position, int count, int columns, E_ModelItemType type)
{
    if (position < 0 || position > childItems.size())
        return false;

    for (int row = 0; row < count; ++row) {
        QVector<QVariant> data(columns);
        MeasureSetupCommonItemModel *item = new MeasureSetupCommonItemModel(data,type,this);
        childItems.insert(position, item);
    }
    return true;
}

bool MeasureSetupCommonItemModel::insertColumns(int position, int columns)
{
    if (position < 0 || position > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.insert(position, QVariant());

    foreach (MeasureSetupCommonItemModel *child, childItems)
        child->insertColumns(position, columns);

    return true;
}

MeasureSetupCommonItemModel *MeasureSetupCommonItemModel::parent()
{
    return parentItem;
}

bool MeasureSetupCommonItemModel::removeChildren(int position, int count)
{
    if (position < 0 || position + count > childItems.size())
        return false;

    for (int row = 0; row < count; ++row)
        delete childItems.takeAt(position);

    return true;
}

bool MeasureSetupCommonItemModel::removeColumns(int position, int columns)
{
    if (position < 0 || position + columns > itemData.size())
        return false;

    for (int column = 0; column < columns; ++column)
        itemData.removeAt(position);

    foreach (MeasureSetupCommonItemModel *child, childItems)
        child->removeColumns(position, columns);

    return true;
}

bool MeasureSetupCommonItemModel::setData(int column, const QVariant &value)
{
    if (column < 0 || column >= itemData.size())
        return false;

    itemData[column] = value;
    return true;
}
