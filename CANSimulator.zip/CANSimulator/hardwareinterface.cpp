#include "hardwareinterface.h"
#include <math.h>
#include <QJsonArray>
#include <QJsonObject>
HardwareInterfaceConfigWindow::HardwareInterfaceConfigWindow(QWidget * parent,HardwareInterfaceManager* manager):
    QMainWindow(parent),
    m_HardwareManager(manager)
{
    setupUi(this);
    refreshWindow();
    connect(m_ButtonBox,SIGNAL(accepted()),this,SLOT(slotOkButton()));
    connect(m_ButtonBox,SIGNAL(rejected()),this,SLOT(slotCancelButton()));
}

void HardwareInterfaceConfigWindow::refreshWindow()
{
    QMap<int,int> baudMap;
    baudMap.insert(0,125);
    baudMap.insert(1,250);
    baudMap.insert(2,500);
    baudMap.insert(3,1000);

    if(m_HardwareManager){
        foreach (const CANHardwareConfig & CANCfg, m_HardwareManager->m_HardwareCfg) {
            if(CANCfg.m_Name == "CAN1"){
                m_CAN1Baud->setCurrentIndex(baudMap.key(CANCfg.m_Baud,2));
                m_CAN1Used->setChecked(CANCfg.m_Used);
            }else if(CANCfg.m_Name == "CAN2"){
                m_CAN2Baud->setCurrentIndex(baudMap.key(CANCfg.m_Baud,2));
                m_CAN2Used->setChecked(CANCfg.m_Used);
            }
        }
   }
    //TODO: disable
    m_CheckConnection->hide();
    m_CheckProgress->hide();
}

void HardwareInterfaceConfigWindow::slotOkButton(){
    QMap<int,int> baudMap;
    baudMap.insert(0,125);
    baudMap.insert(1,250);
    baudMap.insert(2,500);
    baudMap.insert(3,1000);
    if(m_HardwareManager){
        m_HardwareManager->m_HardwareCfg.clear();
        CANHardwareConfig cfg;
        cfg.m_Name = QString("CAN1");
        cfg.m_Baud = baudMap.value(m_CAN1Baud->currentIndex(),500);
        cfg.m_Used = m_CAN1Used->isChecked();
        m_HardwareManager->m_HardwareCfg.append(cfg);

        cfg.m_Name = QString("CAN2");
        cfg.m_Baud = baudMap.value(m_CAN2Baud->currentIndex(),500);
        cfg.m_Used = m_CAN2Used->isChecked();
        m_HardwareManager->m_HardwareCfg.append(cfg);
    }
    close();
}

void HardwareInterfaceConfigWindow::slotCancelButton(){
    close();
}

HardwareInterfaceManager::HardwareInterfaceManager(CANSimulatorDatabaseAssosiate * assosiateDb):
    m_HardwareIO(NULL),
    m_AssosiateDb(assosiateDb)
{

}

HardwareInterfaceManager::~HardwareInterfaceManager(){
    if(m_HardwareIO){
        delete m_HardwareIO;
    }
}

void HardwareInterfaceManager::loadConfig(const QJsonValue & config)
{
    /*
       {
                   "type": "CAN",
                   "AFTER":1,
                   "CAN":[
                        {"name":"CAN1", "used":true,"baud":500 },
                        {"name":"CAN2", "used":false,"baud":500 }
                    ]
       }
*/
    QJsonArray CANarray;
    QJsonObject rootObj, CANObj;
    m_HardwareCfg.clear();
    qDebug()<< config;
    if(config.isObject()){
        rootObj = config.toObject();
        CANarray= rootObj["CAN"].toArray();
        foreach (const QJsonValue &CANitem, CANarray) {
            qDebug()<<CANitem;
            if(CANitem.isObject()){
                CANHardwareConfig cfg;
                CANObj = CANitem.toObject();
                QJsonValue proValue;

                proValue = CANObj["name"];
                cfg.m_Name = proValue.toString();

                proValue = CANObj["used"];
                cfg.m_Used = proValue.toBool();

                proValue = CANObj["baud"];
                cfg.m_Baud = proValue.toInt();

                m_HardwareCfg.append(cfg);
            }
        }
    }
}

const QJsonValue HardwareInterfaceManager::saveConfig()
{
    /*
           {
                       "type": "CAN",
                       "AFTER":1,
                       "CAN":[
                            {"name":"CAN1", "used":true,"baud":500 },
                            {"name":"CAN2", "used":false,"baud":500 }
                        ]
           }
    */
    QJsonArray CANarray;
    QJsonObject rootObj, CANObj;

    foreach (const CANHardwareConfig & canCfg, m_HardwareCfg) {
        CANObj["name"]=canCfg.m_Name;
        CANObj["used"]=canCfg.m_Used;
        CANObj["baud"]=QJsonValue((int)canCfg.m_Baud);
        CANarray.append(CANObj);
    }
    rootObj["CAN"]=CANarray;
    rootObj["connect"]=true;
    rootObj["type"]=QString("CAN");

    return rootObj;
}


void HardwareInterfaceManager::startSimulate(){
    hardwareInit();
}

void HardwareInterfaceManager::stopSimulate(){
    hardwareDeInit();
}

bool HardwareInterfaceManager::hardwareInit()
{
    if(!m_HardwareIO){
        m_HardwareIO = new HardwareIO("COM5",this);
    }
    if(m_HardwareIO->open(QIODevice::ReadWrite | QIODevice::Text) == false){
        return false;
    }
    return true;
}

bool HardwareInterfaceManager::hardwareDeInit()
{
    if(!m_HardwareIO){
        return false;
    }
    if(m_HardwareIO->open(QIODevice::ReadWrite | QIODevice::Text) == false){
        return false;
    }
    return true;

}

bool HardwareInterfaceManager::process(MeasureSetupMessageCommon *message){
    if(!message) return false;
    bool ret=false;
    m_TimeStamp = message->getTimeStamp();

    switch (message->getMessageType()) {
    case E_MsgDataID_Timer:
        ret=true;
        break;
    case E_MsgDataID_CANMsg:
    {
        MeasureSetupMessageCAN * canMsg = static_cast<MeasureSetupMessageCAN*>(message);
        if(canMsg->getMessageInfo().m_Direction==E_Direction_Tx){
            //transmit message
            if(m_HardwareIO){
                qDebug()<< "Send data to CAN";
                //TODO: write data to USB
//                m_HardwareIO->write();
                disconnect(m_HardwareIO,SIGNAL(readyRead()));
                if(m_HardwareIO->waitForReadyRead(200)){
                  //Todo: parse response
                    ret = true;
                }else{
                    //Todo:Transmit failed --> forward message failed
                    ret = false;
                }
                //Fixme:
            }
        }else{
            ret=true;
        }

    }
        break;
    default:
        ret = true;
        break;
    }

    return ret;
}

