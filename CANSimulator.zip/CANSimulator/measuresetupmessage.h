#ifndef MEASURESETUPMESSAGE_H
#define MEASURESETUPMESSAGE_H
#include <utilities.h>
#include <QObject>
typedef enum{
    E_MsgDataID_None=0,
    E_MsgDataID_Timer,
    E_MsgDataID_CANMsg,
    E_MsgDataID_Command,
    E_MsgDataID_Status,
}E_MsgDataID;

typedef enum{
    E_MsgCommand_None=0,
    E_MsgCommand_StartSimulate,
    E_MsgCommand_StopSimulate
}E_MsgCommand;

typedef enum{
    E_MsgStatus_None=0,
    E_MsgStatus_CANTxFailed,
    E_MsgStatus_CANRxFailed
}E_MsgStatus;

class MeasureSetupMessageCommon
{

public:
    MeasureSetupMessageCommon(unsigned long long timestamp=0,
                              E_MsgDataID id=E_MsgDataID_None) :
        m_Timestamp(timestamp),
        m_MsgType(id)
    {}
    E_MsgDataID  getMessageType(){return m_MsgType;}
    unsigned long long getTimeStamp(){return m_Timestamp;}

private:
    E_MsgDataID m_MsgType;
    unsigned long long m_Timestamp;
};


class MeasureSetupMessageCAN: public MeasureSetupMessageCommon
{    
public:
    MeasureSetupMessageCAN(unsigned long long timestamp=0, const CANMessageSimulate & msg = CANMessageSimulate() ):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_CANMsg)
    {
        m_CANMsg =msg;
    }
    MeasureSetupMessageCAN(MeasureSetupMessageCAN& ref):
        MeasureSetupMessageCommon(ref.getTimeStamp(),E_MsgDataID_CANMsg)
    {
        qDebug()<<ref.getMessageInfo().m_Name;
        m_CANMsg = ref.getMessageInfo();
    }

    ~MeasureSetupMessageCAN(){}
    CANMessageSimulate & getMessageInfo(){return m_CANMsg;}
private:
    CANMessageSimulate m_CANMsg;
};

class MeasureSetupMessageCommand: public MeasureSetupMessageCommon
{
public:
    MeasureSetupMessageCommand(unsigned long long timestamp=0, const E_MsgCommand & command = E_MsgCommand_None):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_Command)
    {
        m_Command = command;
        m_CustomData = NULL;
    }
    MeasureSetupMessageCommand(MeasureSetupMessageCommand& ref):
       MeasureSetupMessageCommon(ref.getTimeStamp(),E_MsgDataID_Command)
    {
        m_Command = ref.getCommand();
        m_CustomData = NULL;
    }

    ~MeasureSetupMessageCommand(){}
public:
    E_MsgCommand getCommand(){return m_Command;}

private:
    E_MsgCommand m_Command;
    void * m_CustomData;
};

class MeasureSetupMessageStatus: public MeasureSetupMessageCommon
{
public:
    MeasureSetupMessageStatus(unsigned long long timestamp=0, const E_MsgStatus & status =E_MsgStatus_None):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_Status)
    {
        m_Status=status;
    }
    MeasureSetupMessageStatus(MeasureSetupMessageStatus& ref):
       MeasureSetupMessageCommon(ref.getTimeStamp(),E_MsgDataID_Status)
    {
        m_Status = ref.getStatus();
    }

    ~MeasureSetupMessageStatus(){}
public:
    E_MsgStatus getStatus(){return m_Status;}

private:
    E_MsgStatus m_Status;
};


class MeasureSetupMessageTimer: public MeasureSetupMessageCommon
{
public:
    MeasureSetupMessageTimer(unsigned long long timestamp=0):
        MeasureSetupMessageCommon(timestamp,E_MsgDataID_Timer)
    {
    }
};

#endif // MEASURESETUPMESSAGE_H
