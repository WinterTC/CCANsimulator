#ifndef SIMULATORMVCOMMON_H
#define SIMULATORMVCOMMON_H
#include <QAbstractItemModel>
#include <QVariant>

typedef enum{
    E_ModelItemType_None=0,
    E_ModelItemType_Signal,
    E_ModelItemType_SignalInMessage,
    E_ModelItemType_Mesg
}E_ModelItemType;

class MeasureSetupCommonItemModel
{
public:
    explicit MeasureSetupCommonItemModel(QVector<QVariant> & data,E_ModelItemType itemType, MeasureSetupCommonItemModel *parent = 0);
    ~MeasureSetupCommonItemModel();

    void setType(E_ModelItemType itemType){m_itemType = itemType;}
    E_ModelItemType getType(){return m_itemType ;}

    MeasureSetupCommonItemModel *child(int number);
    int childCount() const;
    int columnCount() const;
    QVariant data(int column) const;
    bool insertChildren(int position, int count, int columns,E_ModelItemType itemType);
    bool insertColumns(int position, int columns);
    MeasureSetupCommonItemModel *parent();
    bool removeChildren(int position, int count);
    bool removeColumns(int position, int columns);
    int childNumber() const;
    bool setData(int column, const QVariant &value);

private:
    E_ModelItemType m_itemType;
    QVector<QVariant>  itemData;
    QList<MeasureSetupCommonItemModel*> childItems;
    MeasureSetupCommonItemModel *parentItem;
};

class MeasureSetupCommonModel:public QAbstractItemModel{
    Q_OBJECT

public:
    MeasureSetupCommonModel( QObject *parent = 0);
    ~MeasureSetupCommonModel();

    QModelIndex index(int row, int column,
                      const QModelIndex &parent = QModelIndex()) const override;
    QModelIndex parent(const QModelIndex &index) const override;

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;

    bool insertColumns(int position, int columns,
                       const QModelIndex &parent = QModelIndex()) override;
    bool removeColumns(int position, int columns,
                       const QModelIndex &parent = QModelIndex()) override;
    bool insertRows(int position, int rows,
                    const QModelIndex &parent = QModelIndex()) override;
    bool removeRows(int position, int rows,
                    const QModelIndex &parent = QModelIndex()) override;
    QVariant data(const QModelIndex &index, int role) const override{}
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override{}
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override{}
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override{}
    Qt::ItemFlags flags(const QModelIndex &index) const override{}


    MeasureSetupCommonItemModel *getItem(const QModelIndex &index) const;


protected:
    MeasureSetupCommonItemModel *rootItem;

    virtual     void setupModelData(MeasureSetupCommonItemModel * parent){}

private:

};
#endif // SIMULATORMVCOMMON_H
