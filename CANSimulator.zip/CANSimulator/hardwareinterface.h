#ifndef HARDWAREINTERFACE_H
#define HARDWAREINTERFACE_H
#include "ui_hardwareinterface.h"
#include "measuresetup.h"
#include "measuresetupmessage.h"
#include <QJsonValue>
#include <QSerialPort>
class HardwareIO;
class HardwareInterfaceManager;
typedef struct CANHardwareConfig{
    QString m_Name;
    bool m_Used;
    unsigned int m_Baud;
}CANHardwareConfig;

class HardwareInterfaceConfigWindow: public QMainWindow,  Ui_hardwareinterface
{
    Q_OBJECT
public:
    HardwareInterfaceConfigWindow(QWidget * parent=0, HardwareInterfaceManager* manager=0);
    void refreshWindow();
signals:
public slots:
    void slotOkButton();
    void slotCancelButton();
private:
    QVector<CANHardwareConfig> m_TmpHardwareCfg;
    HardwareInterfaceManager * m_HardwareManager;
};



class HardwareInterfaceManager:public MeasureSetupManagerCommon{
    Q_OBJECT
public:
    HardwareInterfaceManager(CANSimulatorDatabaseAssosiate * assosiateDb=NULL);
    ~HardwareInterfaceManager();
    void loadConfig(const QJsonValue & config); //load config from Json node
    const QJsonValue saveConfig(); //Save config to an Json node

    void startSimulate();
    void stopSimulate();
    bool process(MeasureSetupMessageCommon *message);
//Add the protocol APIs here (init, send, recv,...)
public slots:

protected:
    bool hardwareInit();
    bool hardwareDeInit();

private:
    CANSimulatorDatabaseAssosiate *m_AssosiateDb;
    friend class HardwareInterfaceConfigWindow;
    QVector<CANHardwareConfig> m_HardwareCfg; //Two CAN port
    HardwareIO *m_HardwareIO;
};

class HardwareIO:public QSerialPort
{
    Q_OBJECT
signals:
    void signalDataReady();
private slots:
    void slotDataReady()
    {
        emit signalDataReady();
    }

public:
    HardwareIO(const QString & port=QString(),QObject * parent=0):
        QSerialPort(port,parent)
    {
        connect(this,SIGNAL(readyRead()),this,SLOT(slotDataReady()));
    }

    qint64 readLine(char * data, qint64 len)
    {
        return QSerialPort::readLine(data,len);
    }

    qint64 write(const char *data, qint64 len){
       return QSerialPort::write(data,len);
    }
    bool open(OpenMode mode){
        return QSerialPort::open(mode);
    }
    void close()
    {
        QSerialPort::close();
    }
};

#endif // HARDWAREINTERFACE_H
